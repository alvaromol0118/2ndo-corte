<?php

require 'config/conex.php';

$cantidad = $_POST["cantidad"];

$total = 1500 * $cantidad;

$sql = "INSERT INTO ventas(valor) VALUES (".$total.")";

if($dbh->query($sql))
{
    echo "Venta registrada";

}else
{
    echo "Error en Venta";

}



?>