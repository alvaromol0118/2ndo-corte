<?php


require 'config/conex.php';

$id= $_POST["id"];
$nombre = $_POST["nombre"];
$celular = $_POST["celular"];

$sql="UPDATE clientes
SET 
nombre='".$nombre."',
celular='".$celular."'
WHERE 
id=".$id." ";

if($dbh->query($sql))
{
    echo "Persona actualizada correctamente";
}else
{
    echo "Error actualizando persona";
}
?>