<?php


require 'config/conex.php';

$id= $_POST["id"];
$gasto = $_POST["gasto"];



?>